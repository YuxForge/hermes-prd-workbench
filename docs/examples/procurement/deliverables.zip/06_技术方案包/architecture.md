# 设备采购与审批系统 — 总体技术方案

> 基线：《设备采购与审批：人工校对 V3 运行基线》（生成稿 run_e30eafa2e88449158078）。
> 本文件描述**待开发的正式系统设计**，不代表任何功能已实现或已验收。原型阶段的内存静态页面只用于确认交互口径，其刷新还原种子数据的行为**不属于**本方案。
> 范围：采购申请 → 审批待办 → 采购订单 → 收货登记四个一级模块。不做付款、税额拆分、库存、资产折旧、退货、撤销收货、撤回审批、取消订单、供应商主数据、消息通知集成。

---

## 1. 技术选型

| 层次 | 选型 | 约束与理由 |
| --- | --- | --- |
| 语言/运行时 | Java 21（LTS） | 使用 record 承载 DTO、switch 模式匹配处理状态分支 |
| Web 框架 | Spring Boot 3.3.x + Spring MVC（Servlet 栈） | 明确不使用 WebFlux；同步阻塞模型足够，事务边界清晰 |
| 持久层 | MyBatis 3.5 + XML Mapper | 收货、审批需要手写条件更新 SQL（`received_qty + ? <= quantity`），ORM 自动脏检查不适用 |
| 校验 | Jakarta Bean Validation + 领域策略类 | 草稿"允许缺必填、已填必须合法"无法只用注解表达，需分组校验 + 策略二次校验 |
| 数据库 | MySQL 8.4，InnoDB，`utf8mb4_0900_ai_ci`，默认 REPEATABLE READ | 金额用整数分存储；并发用行级条件更新，不引入分布式锁 |
| 前端 | Vue 3.4 + TypeScript + Vite 5 + vue-router 4 + Pinia + axios | 组件库（Element Plus）以本地 npm 依赖引入，不使用 CDN |
| 登录态 | 服务端签发的无状态会话串 + Spring MVC `LoginInterceptor` | 单体部署，不引 Session 集群；会话串随自定义请求头提交，服务端验签得到用户与角色 |
| 明确不引入 | 消息队列、Redis、分布式锁、自动重试框架、独立幂等表/幂等键组件、微服务拆分 | 与基线一致；重复请求由唯一约束与状态条件更新返回 409，交用户手动重试 |

部署形态：单个 Spring Boot jar 提供 `/api/**`；前端 `dist` 由 Nginx 或 Spring 静态资源托管，`/api` 反向代理到同进程。开发期 Vite 代理 `/api` 到 8080。

---

## 2. 分层结构与职责

```
com.qinglan.purchase
├─ web/            controller、request/response DTO、GlobalExceptionHandler、LoginInterceptor
├─ application/    用例服务（事务边界 @Transactional）、DTO 组装、数据范围判定调用
├─ domain/         entity、枚举、策略（ApprovalRoutingPolicy、AmountCalculator、ReceiptPolicy）、领域异常
└─ infrastructure/ mapper 接口与 XML、编号生成器、当前用户上下文
```

| 层 | 可以做 | 禁止做 |
| --- | --- | --- |
| web | 参数绑定、Bean Validation 分组、HTTP 状态码映射、角色注解声明 | 写业务判断、直接调 Mapper、拼接金额 |
| application | 编排用例、开启事务、加载聚合、校验状态机前置条件、组装响应 | 内联复杂金额/路由规则（应下沉 domain） |
| domain | 状态流转合法性、审批路由、收货数量规则、金额分计算 | 依赖 Spring Web、访问数据库 |
| infrastructure | SQL、唯一约束冲突翻译、会话串验签 | 决定业务分支 |

**规则落点约定**：可被数据库表达的（唯一单号、一申请一订单、行号唯一、非空、金额非负）一律加约束兜底；跨行/跨表规则（全 0 拦截、超收、审批路由）在 application + domain 校验，并以条件更新作为并发下的最终防线。二者不可只留其一。

---

## 3. 模块边界与依赖

| 模块 | 职责 | 允许依赖 | 不负责 |
| --- | --- | --- | --- |
| purchase-request | 申请聚合的建立、编辑、提交、重提、详情聚合读 | domain 公共内核 | 审批决策、建单、收货 |
| approval-todo | 待办查询、通过/驳回、轮次推进、审批留痕 | purchase-request 的状态与金额（只读）、pr_approval_record | 修改申请行、改金额、改部门 |
| purchase-order | 建单、快照复制、下单、订单查询 | purchase-request（校验 APPROVED 并读行） | 改申请、登记收货 |
| receiving | 收货登记、累计量推进、订单状态推进 | purchase-order（读订单与行、条件更新累计量） | 建单、下单、撤销收货 |
| 公共内核 | 金额（分）、状态枚举、单号、数据范围、错误码 | — | 任何页面逻辑 |

依赖是单向的：`receiving → purchase-order → purchase-request`，`approval-todo → purchase-request`。禁止 purchase-request 反向调用审批或订单服务；申请详情中的订单/收货进度由**读模型**在同一请求内查询订单与收货表，不形成写依赖。

**跨模块共享数据只有一处写入口**：申请状态只由 `PurchaseRequestService`（提交/重提）与 `ApprovalService`（决策）修改；订单状态只由 `PurchaseOrderService`（下单）与 `ReceiptService`（收货）修改。其他代码只读。

---

## 4. 实体关系

```mermaid
erDiagram
    SYS_DEPT ||--o{ SYS_USER : "包含人员"
    SYS_DEPT ||--o{ PR_APPLICATION : "归属部门"
    SYS_USER ||--o{ PR_APPLICATION : "申请人"
    PR_APPLICATION ||--|{ PR_APPLICATION_ITEM : "行明细"
    PR_APPLICATION ||--o{ PR_APPROVAL_RECORD : "审批轮次记录"
    PR_APPLICATION ||--o| PO_ORDER : "最多一张订单"
    PO_ORDER ||--|{ PO_ORDER_ITEM : "快照行"
    PR_APPLICATION_ITEM ||--o| PO_ORDER_ITEM : "来源行"
    PO_ORDER ||--o{ RC_RECEIPT : "收货单"
    RC_RECEIPT ||--|{ RC_RECEIPT_ITEM : "本次明细"
    PO_ORDER_ITEM ||--o{ RC_RECEIPT_ITEM : "累计收货"
```

关键基数：一个申请 1..N 行、0..1 订单；一个订单 1..N 行、0..N 收货单（分批）；订单行与申请行 1:1 快照对应；收货明细只记录**本次实际收货行**（未参与行不落库）。订单行上的 `received_qty` 是累计冗余列，用于并发校验与进度展示，权威明细仍在 `rc_receipt_item`，二者在同一事务内更新。

---

## 5. 状态机

### 5.1 采购申请

```mermaid
stateDiagram-v2
    [*] --> DRAFT : 保存草稿（生成申请号/版本1/轮次1）
    DRAFT --> PENDING_MANAGER : 提交（全量必填校验）
    PENDING_MANAGER --> APPROVED : 主管通过 且 总额 <= 5000.00
    PENDING_MANAGER --> PENDING_FINANCE : 主管通过 且 总额 > 5000.00
    PENDING_FINANCE --> APPROVED : 财务通过
    PENDING_MANAGER --> REJECTED : 主管驳回（理由必填）
    PENDING_FINANCE --> REJECTED : 财务驳回（理由必填）
    REJECTED --> PENDING_MANAGER : 原单重提（version+1，round_no+1）
    APPROVED --> [*]
    REJECTED --> [*]
```

- 申请**没有**"已完成"状态：订单与收货进度是关联展示，不反写申请状态（基线明确要求）。
- 无可提交审批人时（财务方宁本人申请、或部门无主管）：**停留在 DRAFT**，返回 422 `NO_ELIGIBLE_APPROVER` 与提示文案，不产生待办。这是案例的保守临时决定。
- 草稿与已驳回可编辑；待主管审批/待财务复核只读；已批准永久只读。

### 5.2 采购订单

```mermaid
stateDiagram-v2
    [*] --> PENDING_ORDER : 建单（仅 APPROVED 申请，一申请一单）
    PENDING_ORDER --> PENDING_RECEIVE : 下单（供应商+预计到货日，校验通过）
    PENDING_RECEIVE --> PARTIALLY_RECEIVED : 首次/后续收货，仍有行未收齐
    PARTIALLY_RECEIVED --> PARTIALLY_RECEIVED : 继续分批收货
    PARTIALLY_RECEIVED --> COMPLETED : 所有行 received_qty = quantity
    PENDING_RECEIVE --> COMPLETED : 首次收货即全部收齐
    PENDING_ORDER --> [*]
    COMPLETED --> [*]
```

`PENDING_ORDER` 与 `COMPLETED` 没有收货入口。已下单订单不可编辑、不可取消；收货记录不可改、不可撤销。

---

## 6. 关键流程

### 6.1 提交审批

```mermaid
sequenceDiagram
    participant FE as Vue 申请详情
    participant C as PurchaseRequestController
    participant S as PurchaseRequestService
    participant D as ApprovalRoutingPolicy
    participant DB as MySQL
    FE->>C: POST /purchase-requests/{id}/submit (rowVersion)
    C->>S: submit(id, currentUser, rowVersion)
    S->>DB: SELECT 申请(含行) WHERE id=? AND deleted=0
    S->>S: 数据范围校验（仅本人；状态 DRAFT/REJECTED）
    S->>D: 全量必填 + 格式 + 金额重算
    D-->>S: 通过 / 字段错误列表
    S->>S: 解析审批起点（部门主管；财务本人→拒绝）
    S->>DB: UPDATE pr_application SET status='PENDING_MANAGER', version=?, round_no=?, row_version=row_version+1, submitted_at=now() WHERE id=? AND row_version=? AND status IN ('DRAFT','REJECTED')
    alt 影响行数 = 0
        S-->>C: 409 STATE_CONFLICT
    else 成功
        S->>DB: INSERT pr_approval_record 初始轮次占位（step=MANAGER, action=PENDING）
        S-->>C: 200 {status, version, roundNo}
    end
```

提交时**重算**行金额与总额（数量 × 单价，分），不信任前端总额；行金额 `quantity * unit_price_cents` 为整数运算，无浮点误差，审批路由只读这个整数。

### 6.2 审批决策与金额路由

```
decision(applicationId, action, reason, rowVersion):
  1. 加载申请；校验 status ∈ {PENDING_MANAGER, PENDING_FINANCE}
  2. 校验当前用户的待办归属：
     - step=MANAGER：user.dept == application.dept 且 role=MANAGER，或命中代审授权（周禾↔许原 本人申请）
     - step=FINANCE：role=FINANCE（跨部门）
  3. approver == applicant → 403 SELF_APPROVAL_FORBIDDEN
  4. action=REJECT 且 reason 为空/超 200 字 → 400 字段错误，状态不变
  5. action=APPROVE:
       total <= 5_000_00 分  → next = APPROVED
       total >  5_000_00 分  → 当前 step=MANAGER ? PENDING_FINANCE : APPROVED
  6. UPDATE pr_application SET status=next, row_version=row_version+1
       WHERE id=? AND row_version=? AND status=<读取时状态>
     影响 0 行 → 409（他人已处理或版本过期）
  7. INSERT pr_approval_record(action, is_delegate, reason, decided_at, application_version=version)
```

- 阈值唯一口径：`total_amount_cents <= 500000` 单级；`500001` 与 `860000` 两级。不设 10,000 元口径。
- 一轮内每 step 只允许一条终态记录；唯一键 `(application_id, round_no, step)` 防止重复决策落两条。
- 代审必须写 `is_delegate=1` 与 `delegate_of_user_id`，并在时间线标注"代审"。

### 6.3 建单与下单

建单：校验申请 `APPROVED`、当前用户 role=BUYER、该申请无订单（`uk_application_id` 兜底）→ 复制行快照（名称/规格/单位/数量/单价/行金额）→ 订单 `PENDING_ORDER`。申请保持 `APPROVED` 不变。
下单：校验 `PENDING_ORDER`、供应商 1–100 字、预计到货日 ≥ 当天 → `PENDING_RECEIVE` 并写 `ordered_at`。已下单不可重复下单（条件更新，影响 0 行 → 409）。

### 6.4 收货事务（核心）

单个本地事务，无跨库、无外部调用：

```sql
-- 步骤 2：逐行条件累加，超收即失败（不做先查后改的竞态判断）
UPDATE po_order_item
   SET received_qty = received_qty + #{qty}, row_version = row_version + 1
 WHERE id = #{itemId}
   AND order_id = #{orderId}
   AND received_qty + #{qty} <= quantity;
```

1. 校验订单状态 ∈ {`PENDING_RECEIVE`, `PARTIALLY_RECEIVED`}、当前用户 role=WAREHOUSE。
2. 组装**有效行**：`qty != null && qty > 0` 的明细；`null` 与 `0` 直接丢弃、不写 `rc_receipt_item`。
3. 有效行为空 → 422 `EMPTY_RECEIPT_LINES`（全 0/全空拦截），事务不开启写操作。
4. 每行数量必须是正整数（前端整数控件 + 服务端 `Integer` 类型，拒绝小数与负数）。
5. 按上表逐行执行条件更新，任一行影响 0 行 → 抛 `OVER_RECEIPT`，整事务回滚（此前已加的行也回滚），返回 409 并回传该行 `orderedQty/receivedQty/pendingQty` 供前端刷新。
6. 汇总本次有效数量，判定：全部订单行 `received_qty == quantity` → `COMPLETED`，否则 `PARTIALLY_RECEIVED`。
7. `UPDATE po_order SET status=?, row_version=row_version+1 WHERE id=? AND status IN (...)`；影响 0 行 → 409。
8. `INSERT rc_receipt` + 批量 `INSERT rc_receipt_item`（每行一条，`received_qty` = 本次数量）。

并发语义：两个仓管同时提交同一行时，第二条的条件更新必然失败（`received_qty` 已被抬升），返回 409 而不是超收；不需要分布式锁或 SELECT FOR UPDATE。所有校验都在同一事务内，失败不留半条记录。

---

## 7. 登录态与数据范围

- 登录成功后服务端签发会话串：内含 `userId`、`roleCode`、`deptId` 与 8 小时有效期，服务端验签即可还原身份，不查会话表。前端存内存 + `sessionStorage`，每次请求在自定义请求头 `X-Login-Session` 中携带。
- `LoginInterceptor` 验签后写入 `UserContext`（ThreadLocal，请求结束清理）；缺失/过期 → 401 `UNAUTHENTICATED`。
- 控制器方法标注 `@RequireRoles({BUYER})`；更细的"仅本人""仅本部门"由 `DataScopeService` 在服务层判断，**不依赖前端隐藏按钮**。
- 越权语义：角色不允许 → 403 `FORBIDDEN_ROLE`；角色允许但数据不在范围 → 403 `OUT_OF_DATA_SCOPE`；记录不存在 → 404。财务访问订单/收货接口一律 403，不返回"无数据"的空列表（避免被误读为无记录）。

| 端点 | APPLICANT | MANAGER | FINANCE | BUYER | WAREHOUSE |
| --- | --- | --- | --- | --- | --- |
| 申请列表/详情 | 本人 | 本部门（含待办） | 待财务复核及历史（**不含**订单/收货段） | 已批准只读 | 已建单申请必要字段 |
| 建/改草稿、提交 | 本人 | 本人 | 仅草稿，**不可提交** | 403 | 403 |
| 审批决策 | 403 | 本部门且非本人 / 授权代审 | 非本人 | 403 | 403 |
| 建单/下单 | 403 | 403 | 403 | 允许 | 403 |
| 订单/收货查询 | 只读本人关联 | 只读本部门关联 | **403** | 全部 | 待收货/部分收货及历史 |
| 收货登记 | 403 | 403 | 403 | 403 | 允许 |

财务角色的申请详情响应中，`orderProgress` 字段整体省略（`null`），不返回订单号、供应商、收货数量。

---

## 8. 接口与错误约定

统一响应体：

```json
{ "code": "OK", "message": "success", "data": {}, "traceId": "b7c1e0f2" }
```

- 分页：`page` 从 1 开始，`size` 固定默认 10（允许 10/20/50），`sort=createdAt,desc` 为唯一默认排序，不接受任意字段排序。响应 `data = { list, page, size, total, pages }`。
- 搜索：`keyword` 对单号与标题做 `LIKE '%kw%'`（前缀索引无法覆盖，数据量小可接受；超 10 万单再评估全文索引）。`status` 精确匹配，多值用逗号分隔。
- 空结果返回 `list: []`，前端渲染"暂无匹配单据"。
- 金额出参：同时给 `amountCents`（整数，权威）与 `amount`（字符串两位小数），前端只展示字符串、只回传分。
- 日期：`yyyy-MM-dd`（到货日），时间戳 `yyyy-MM-dd HH:mm:ss`（东八区，服务端统一）。

错误码（HTTP + 业务码双维度）：

| HTTP | 业务码 | 场景 |
| --- | --- | --- |
| 400 | `VALIDATION_FAILED` | 字段格式/长度/范围错误，附 `fieldErrors[]` |
| 400 | `REASON_REQUIRED` | 驳回未填理由 |
| 401 | `UNAUTHENTICATED` | 未登录或登录态过期 |
| 403 | `FORBIDDEN_ROLE` / `OUT_OF_DATA_SCOPE` / `SELF_APPROVAL_FORBIDDEN` | 角色、范围、自审 |
| 404 | `NOT_FOUND` | 单据不存在 |
| 409 | `STATE_CONFLICT` | 状态已变化（已被他人审批/下单/收货） |
| 409 | `VERSION_CONFLICT` | `rowVersion` 过期 |
| 409 | `DUPLICATE_ORDER` | 该申请已有订单 |
| 409 | `DUPLICATE_NO` | 单号唯一冲突（用户手动重试） |
| 409 | `OVER_RECEIPT` | 本次数量导致累计超订购量 |
| 422 | `EMPTY_RECEIPT_LINES` | 全部行空或 0 |
| 422 | `NO_ELIGIBLE_APPROVER` | 财务本人申请 / 部门无主管 |
| 422 | `INVALID_STATUS_TRANSITION` | 非法流转（如草稿直接建单） |
| 500 | `INTERNAL_ERROR` | 未预期异常，隐藏堆栈 |

409 一律**不自动重试**，前端提示"数据已被更新，请刷新后重试"并重新拉取详情。500 仅记录 traceId，不回显 SQL。

---

## 9. 金额、编号与校验口径

- 行金额 = `quantity × unit_price_cents`，`long` 运算；总额 = 各行之和。入库 `BIGINT`，出参转 `BigDecimal.movePointLeft(2).setScale(2)`。
- 单价入参：`BigDecimal`，`scale ≤ 2`，范围 `0.00–999999.99`，0 元合法；服务端 `setScale(2, UNNECESSARY)` 后 ×100 转分，避免 `0.1+0.2` 类误差。
- 数量：`1–999` 整数，`Integer` 类型直接拒绝 `1.5`。
- 单号：`SQ`/`DD`/`SH` + `yyyyMMdd` + 8 位（时间戳后 6 位 + 随机 2 位）；唯一索引兜底，冲突返回 409 由用户重试。**不使用缓存自增、不使用重试循环**。
- 草稿：允许标题/用途/到货日/明细缺失；已填字段仍须格式合法（日期可解析、数量在 1–999、单价两位小数）。提交才做全量必填。
- 期望到货日：提交时不得早于当天；历史记录保留原值（已存日期不因时间推移而变成非法）。
- 部门：从 `sys_user.dept_id` 取，请求体中的 `deptId` 一律忽略（防止越权改部门）。

---

## 10. 前端结构与约定

```
src/
├─ api/            request.ts（axios 实例、401 跳登录、409 统一提示）、purchase.ts、approval.ts、order.ts、receipt.ts
├─ stores/         session.ts（用户/角色/权限）、dict.ts（状态枚举与中文标签）
├─ router/         index.ts（createWebHistory，路由守卫按角色过滤）
├─ views/          request/List.vue、request/Detail.vue、request/Form.vue
│                  approval/Todo.vue、approval/Detail.vue
│                  order/List.vue、order/Detail.vue、order/Create.vue
│                  receiving/Detail.vue（收货表单内嵌订单详情）
└─ components/     StatusTag.vue、MoneyText.vue、Timeline.vue、EmptyState.vue、ConfirmDialog.vue
```

- 列表页统一：顶部单号/标题搜索 + 状态筛选，表头按创建时间倒序，底部分页 10 条，空态文案"暂无匹配单据"。
- 状态标签与颜色集中在一处映射，禁止各页面自行硬编码中文。
- 页面上所有动作按钮的可见性只是体验优化；服务端 403/409 是唯一权威。按钮点击后禁用直至响应返回，防止重复提交。
- 详情页时间线由后端一次性返回（`timeline: [{time, actor, action, detail}]`），前端只渲染，不拼接。
- 刷新页面必须从接口重新取数（正式系统持久化），不得沿用原型的内存种子数据逻辑。

---

## 11. 与基线的差异与遗留假设

| 项 | 本方案选择 | 状态 |
| --- | --- | --- |
| 财务本人申请 | 仅可存草稿，提交返回 422 并给出联系管理员文案 | 基线临时决定，需业务确认 |
| 单号格式 | 前缀 + 日期 + 8 位随机，唯一索引兜底 | 仅要求唯一，格式需确认 |
| 主管历史查询范围 | 不新增独立历史入口，仅本部门列表 | 基线 Q3 未确认 |
| 预计到货日上限 | 不设上限，仅要求 ≥ 当天 | 需业务确认 |
| 重提审批人 | 按角色池先到先审，仍禁止自审 | 需业务确认 |
| 长期未收齐 | 不提醒、不自动关闭 | 需业务确认 |
| 审批撤回 | 不支持 | 明确不做 |
| 权限模型 | 单角色（`sys_user.role_code`），不做多角色与角色管理页 | 基线"预置角色，不增加角色管理" |

并发、权限、金额路由这三类结论必须由独立测试验证；本方案不宣称已通过验收。

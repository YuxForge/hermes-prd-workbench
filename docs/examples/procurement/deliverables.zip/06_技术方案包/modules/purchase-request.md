# 模块一：采购申请（purchase-request）

## 1. 职责边界

负责申请聚合的**建立、草稿编辑、提交、被驳回后重提、详情聚合读**。不负责审批决策（approval-todo）、不建订单（purchase-order）、不登记收货（receiving）。申请状态只由本模块的提交/重提与审批模块的决策两处修改。

## 2. 页面与接口对照

| 页面 | 路由 | 主要动作 | 接口 |
| --- | --- | --- | --- |
| 申请列表 | `/requests` | 关键词/状态筛选、分页、进入详情、新建 | `GET /api/v1/purchase-requests`、`POST /api/v1/purchase-requests` |
| 申请详情 | `/requests/:id` | 查看行明细/审批轮次/时间线/订单进度；草稿或驳回单进入编辑或提交 | `GET /api/v1/purchase-requests/{id}`、`POST /api/v1/purchase-requests/{id}/submit` |
| 申请表单 | `/requests/new`、`/requests/:id/edit` | 保存草稿、整组编辑明细 | `POST /api/v1/purchase-requests`、`PUT /api/v1/purchase-requests/{id}` |

前端表单为单页三段：基本信息（标题/用途/部门只读/期望到货日）、明细表格（可增删行，行号前端生成后由服务端重排）、底部合计。合计必须用整数分计算，与后端一致，避免 4500.00 与 4499.99 的显示分歧。

## 3. 字段与校验落地

| 字段 | 草稿 | 提交 | 校验位置 | 失败反馈 |
| --- | --- | --- | --- | --- |
| 标题 | 可空 | 必填 1–100 字 | `@Size` + `DraftValidationGroup` 跳过 `@NotBlank` | 字段级红字 |
| 用途 | 可空 | 必填 1–500 字 | 同上 | 字段级红字 |
| 部门 | 只读，取登录人 `dept_id` | 同左 | 服务端覆盖，忽略请求体 | — |
| 期望到货日 | 可空 | 必填，且 ≥ 提交当天 | `SubmitValidation` + `LocalDate.now(ZoneId.of("Asia/Shanghai"))` | "期望到货日不能早于今天" |
| 明细行 | 可空 | ≥1 行 | 提交时 `items.isEmpty()` → 字段错误 | "请至少添加一行物品" |
| 物品名称 | 可空 | 1–100 字 | 行级校验 | 行内提示 |
| 规格 | 可空 | ≤100 字 | 行级校验 | 行内提示 |
| 单位 | 可空 | 台/个/件 | 枚举校验 | 行内提示 |
| 数量 | 可空 | 1–999 整数 | `Integer` 类型 + `@Min/@Max` | "数量须为 1–999 的整数" |
| 单价 | 可空 | 0–999999.99，≤2 位小数 | `BigDecimal` + `setScale(2, UNNECESSARY)` | "单价最多两位小数" |

**两段式校验**是核心：草稿走 `Draft` 分组，只做"已填即合法"；提交走 `Submit` 分组并再执行 `PurchaseRequestPolicy.validateForSubmit()`（含明细非空、日期、总额重算）。不允许用一个 `@Valid` 兼顾两种语义。

## 4. 关键规则落地

1. **建草稿生成单号**：`SQ + yyyyMMdd + 8位`，`uk_apply_no` 兜底；`DuplicateKeyException` → 409 `DUPLICATE_NO`，**不重试生成**。
2. **版本与轮次**：创建时 `version=1, round_no=1`；重提时 `version=version+1, round_no=round_no+1`，单号不变。二者必须同一事务内一起递增，禁止只加其一。
3. **草稿整组替换**：`PUT` 先 `DELETE FROM pr_application_item WHERE application_id=?` 再批量插入（草稿行无历史价值），必须在同一事务内；已提交行永不删除。
4. **提交即锁单**：成功后状态 `PENDING_MANAGER`，申请人不可编辑、不可撤回（基线不做撤回）。前端把详情页切为只读并隐藏提交按钮，服务端仍以状态条件更新拒绝二次提交。
5. **重提不继承结果**：新轮次从主管重新开始，旧轮审批记录保留且不可改；`pr_approval_record` 以 `round_no` 区分，详情页按轮次分组展示。
6. **金额重算**：提交时对每行 `line_amount_cents = quantity * unit_price_cents`（`long`），总额求和后落库；前端传入的任何总额字段被忽略。审批阈值判断只读该整数。
7. **提交路由**：申请人部门取在职主管（`role_code='MANAGER'` 且 `dept_id` 相同、`status=1`）；财务角色本人申请、或部门无主管 → 422 `NO_ELIGIBLE_APPROVER`，状态保持 `DRAFT`，不写审批记录、不产生待办。
8. **详情聚合读**：一次请求内组装主表、行、`pr_approval_record`（全部轮次）、时间线、订单进度。时间线不落表，按 `created_at / submitted_at / approval.decided_at / order.ordered_at / receipt.received_at` 合并后按时间正序，标注操作人。
9. **订单进度**：仅当存在订单时返回 `orderProgress`，含订单号、状态、行级 `orderedQty/receivedQty/pendingQty`。申请人只能看本人申请关联的，主管只能看本部门。**财务返回 null**。
10. **已批准永久只读**：无任何编辑入口，`PUT` 对 `APPROVED` 返回 422 `INVALID_STATUS_TRANSITION`。

## 5. 数据范围

| 角色 | 可见范围 | 可写 | 禁止 |
| --- | --- | --- | --- |
| 申请人 | `applicant_id = 当前用户` | 建草稿、改草稿/驳回单、提交 | 审批、看他人单据 |
| 主管 | `dept_id = 本人部门`（含本人申请） | 建本人申请、改本人草稿、提交 | 审批本人申请（转代审）、跨部门 |
| 财务 | `status ∈ {PENDING_FINANCE, APPROVED, REJECTED}` 的跨部门单据，**不含订单/收货段** | 本人草稿（不可提交） | 看订单、收货、代采购动作 |
| 采购 | `status = APPROVED` 且未有订单的申请（履行需要） | 无 | 新建/修改/提交/审批 |
| 仓管 | 已建单申请的必要字段 | 无 | 编辑任何申请 |

列表 SQL 的数据范围必须拼在 `WHERE` 中，不允许"查全量再过滤"。分页总数按过滤后的条件统计。

## 6. 异常与 HTTP 映射

| 场景 | HTTP | 业务码 | 前端处理 |
| --- | --- | --- | --- |
| 草稿字段格式非法（日期/数量/单价） | 400 | `VALIDATION_FAILED` | 定位行与字段 |
| 提交缺标题/用途/到货日/明细 | 400 | `VALIDATION_FAILED` + `fieldErrors` | 高亮缺失项，停留详情页 |
| 改他人单据 | 403 | `OUT_OF_DATA_SCOPE` | 提示无权限并返回列表 |
| 采购/仓管调用写接口 | 403 | `FORBIDDEN_ROLE` | 隐藏入口（服务端仍拒绝） |
| 编辑非草稿/非驳回单 | 409 | `STATE_CONFLICT` | 提示刷新 |
| `rowVersion` 过期 | 409 | `VERSION_CONFLICT` | 重新拉详情，用户重填 |
| 单号冲突 | 409 | `DUPLICATE_NO` | "请稍后重试"，不自动重试 |
| 无可用审批人 | 422 | `NO_ELIGIBLE_APPROVER` | 展示基线文案，保留草稿 |

## 7. 索引与查询注意

- 列表主查询走 `(applicant_id, status, created_at)` 或 `(dept_id, status, created_at)`，`ORDER BY created_at DESC` 可避免 filesort（前缀列等值）。
- `keyword` 为 `apply_no LIKE ? OR title LIKE ?`，两列 OR 无法走单索引；数据量小可接受，若超 10 万单再引入前缀匹配或独立搜索。
- 详情按 `id` 主键取，行明细走 `idx_application`，审批记录走 `idx_app_round`。

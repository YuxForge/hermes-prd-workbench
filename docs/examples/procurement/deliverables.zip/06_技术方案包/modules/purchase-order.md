# 模块三：采购订单（purchase-order）

## 1. 职责边界

负责：在**已批准**申请上建单、复制批准版本快照、下单（填供应商与预计到货日）、订单列表与详情查询。不修改申请、不修改快照金额与数量、不登记收货、不取消订单、不做付款。

## 2. 页面与接口对照

| 页面 | 路由 | 动作 | 接口 |
| --- | --- | --- | --- |
| 订单列表 | `/orders` | 关键词/状态筛选、分页、进入详情 | `GET /api/v1/purchase-orders` |
| 建单页 | `/orders/new?applicationId=` | 预览批准行快照、创建订单 | `POST /api/v1/purchase-orders` |
| 订单详情 | `/orders/:id` | 查看快照行、收货进度、收货历史；待下单时填供应商/到货日下单；仓管进入收货表单 | `GET /api/v1/purchase-orders/{id}`、`POST /api/v1/purchase-orders/{id}/place` |

建单入口在采购的"已批准申请"列表与申请详情中；若该申请已有订单，入口直接跳转已有订单详情，并提示"该申请已建单"。

## 3. 建单规则

1. 前置：申请 `status='APPROVED'`；当前用户 `role_code='BUYER'`。
2. 唯一性：`uk_application_id` 保证一申请一单。应用层先查一次给出友好提示，数据库唯一键作为并发最终防线；捕获 `DuplicateKeyException` 后查已有订单，返回 409 `DUPLICATE_ORDER` 并带 `existingOrderNo`。
3. 快照内容：`item_name / spec / unit / quantity / unit_price_cents / line_amount_cents` 全部从 `pr_application_item` 复制，`application_item_id` 保留追溯；快照列与申请行**解耦**，后续申请（已批准不可改）不会影响订单。
4. 订单号 `DD + yyyyMMdd + 8位`，唯一索引兜底，冲突 409 由用户重试。
5. 初始状态 `PENDING_ORDER`，`supplier_name`、`expected_arrival_date` 为空，`ordered_at` 为空。
6. 申请状态保持 `APPROVED`，**不**写"已完成"或"已下单"状态；申请详情通过 `orderProgress` 关联展示。

## 4. 下单规则

| 校验 | 规则 | 失败 |
| --- | --- | --- |
| 状态 | 必须 `PENDING_ORDER` | 422 `INVALID_STATUS_TRANSITION` / 409 `STATE_CONFLICT` |
| 供应商 | 必填，去空格后 1–100 字，自由文本 | 400 `VALIDATION_FAILED` |
| 预计到货日 | 必填，`>= 下单当天`（Asia/Shanghai） | 400 `VALIDATION_FAILED` |
| 并发 | `WHERE status='PENDING_ORDER' AND row_version=?` | 影响 0 行 → 409 |

成功后 `status='PENDING_RECEIVE'`、`ordered_at=now()`、`row_version+1`。已下单订单不提供任何编辑接口；供应商/日期不可改（基线未要求修改，按不可变实现，避免与收货进度口径冲突）。不提供取消。

## 5. 列表与详情口径

- 列表默认 `created_at DESC`，10 条/页。字段：订单号、关联申请号/标题、供应商、金额、状态、创建时间、收货进度。
- 收货进度 `progress = Σreceived_qty / Σquantity`，实时由 `po_order_item` 聚合，不存汇总列，避免与明细不一致。
- 详情行必须同时给出 `quantity / receivedQty / pendingQty`，其中 `pendingQty = quantity - receivedQty`（`CHECK` 约束保证非负）。
- 详情时间线：创建订单 → 下单（含供应商）→ 每次收货（含记录号与登记人），只读。
- `canReceive` 由服务端按"状态 + 角色"计算，前端仅用于显隐；即使被篡改，收货接口仍独立校验。

## 6. 状态与可见性

| 订单状态 | 含义 | 仓管可见 | 收货入口 | 采购可操作 |
| --- | --- | --- | --- | --- |
| `PENDING_ORDER` | 已建单未下单 | 否（列表默认过滤） | 无 | 可下单 |
| `PENDING_RECEIVE` | 已下单待收货 | 是 | 有 | 只读 |
| `PARTIALLY_RECEIVED` | 已有收货但未收齐 | 是 | 有 | 只读 |
| `COMPLETED` | 全部行收齐 | 是（历史） | 无 | 只读 |

仓管列表默认只查 `PENDING_RECEIVE, PARTIALLY_RECEIVED`，可通过状态筛选看历史（`COMPLETED`）。财务对订单与收货接口一律 403，不返回空列表。

## 7. 异常清单

| 场景 | HTTP | 业务码 |
| --- | --- | --- |
| 非采购员建单/下单 | 403 | `FORBIDDEN_ROLE` |
| 申请不存在或不可见 | 404 | `NOT_FOUND` |
| 申请非已批准 | 422 | `INVALID_STATUS_TRANSITION` |
| 重复建单 | 409 | `DUPLICATE_ORDER` |
| 订单已下单后再下单 | 409 | `STATE_CONFLICT` |
| 供应商/日期非法 | 400 | `VALIDATION_FAILED` |
| 财务读取订单 | 403 | `FORBIDDEN_ROLE` |
| 申请人读非关联订单 | 403 | `OUT_OF_DATA_SCOPE` |

## 8. 数据一致性

- 建单在一个事务内：插入 `po_order` → 批量插入 `po_order_item`。任一失败回滚，不产生"无行订单"。
- 订单总额以快照行求和落库，同时与申请总额做一次比对；不一致说明数据异常，直接 500 并记录 traceId（正常流程不可能出现）。
- `po_order_item.received_qty` 初始 0，只允许收货事务通过条件更新递增，任何编辑接口都不得直接赋值。
- 订单与申请之间无级联删除；两张表都不做物理删除。

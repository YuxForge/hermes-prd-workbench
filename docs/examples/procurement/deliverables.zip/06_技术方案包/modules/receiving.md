# 模块四：收货登记（receiving）

## 1. 职责边界

仓管对**待收货/部分收货**订单登记本次到货量，系统累加行级已收数量、写收货记录、推进订单状态。不提供退货、撤销收货、修改历史记录；不建单、不下单、不修改订单金额与订购数量。

## 2. 页面与接口对照

| 页面 | 路由 | 动作 | 接口 |
| --- | --- | --- | --- |
| 待收货列表 | `/receiving` | 只看待收货/部分收货订单，进入登记 | `GET /api/v1/purchase-orders?status=PENDING_RECEIVE,PARTIALLY_RECEIVED` |
| 收货登记 | `/receiving/:orderId` | 查看订购/已收/待收，按行填本次数，提交 | `GET /api/v1/purchase-orders/{id}`、`POST /api/v1/purchase-orders/{id}/receipts` |

登记页表格列：行号、物品、规格、单位、订购数、累计已收、待收、**本次数量**（唯一可编辑列）。待收为 0 的行输入框禁用。底部显示本次合计件数与备注框。

## 3. 数量规则（本模块核心）

| 输入 | 处理 |
| --- | --- |
| 空（`null`） | 视为未参与，不写明细、不累加 |
| `0` | 同空，不写明细（前端允许保留 0，后端归一为"未参与"） |
| 正整数且 `<= 待收` | 有效行，写 `rc_receipt_item`，条件累加 |
| 负数 / 小数 / 非数字 | 400 `VALIDATION_FAILED`，整单不提交 |
| 大于待收 | 409 `OVER_RECEIPT`，整单回滚，返回该行 `pendingQty` |
| 全部行空或 0 | 422 `EMPTY_RECEIPT_LINES`，不写记录、不改累计 |

DTO 中 `receivedQty` 必须是 `Integer`；`1.5` 在反序列化阶段即失败，不进入业务逻辑。前端使用整数步进控件（`step=1`、`precision=0`），并在失焦时把空串归一为 `null`。

## 4. 事务步骤（逐条对应实现）

```java
@Transactional(rollbackFor = Exception.class)
public ReceiptResult receive(Long orderId, ReceiptCommand cmd, UserContext user) {
    // 1. 角色与订单状态
    requireRole(user, WAREHOUSE);
    PoOrder order = orderMapper.selectById(orderId);          // 不存在 → 404
    if (!RECEIVABLE.contains(order.getStatus())) throw new BizException(INVALID_STATUS_TRANSITION);
    if (!order.getRowVersion().equals(cmd.getRowVersion())) throw new BizException(VERSION_CONFLICT);

    // 2. 过滤有效行：null 与 0 丢弃
    List<Line> effective = cmd.getItems().stream()
        .filter(i -> i.getReceivedQty() != null && i.getReceivedQty() > 0)
        .toList();
    // 3. 全 0 / 全空拦截，写操作尚未发生
    if (effective.isEmpty()) throw new BizException(EMPTY_RECEIPT_LINES);

    // 4. 逐行条件累加，超收即抛异常回滚
    for (Line l : effective) {
        int affected = orderItemMapper.addReceived(l.getItemId(), orderId, l.getReceivedQty());
        if (affected == 0) throw new BizException(OVER_RECEIPT, pendingQtyOf(l.getItemId()));
    }

    // 5. 判定是否全部收齐
    boolean allDone = orderItemMapper.countUnfinished(orderId) == 0;
    String next = allDone ? COMPLETED : PARTIALLY_RECEIVED;

    // 6. 订单状态条件更新（防并发推进）
    int updated = orderMapper.advance(orderId, order.getStatus(), cmd.getRowVersion(), next);
    if (updated == 0) throw new BizException(STATE_CONFLICT);

    // 7. 写收货头 + 明细（仅有效行）
    RcReceipt receipt = insertReceipt(orderId, user, effective, cmd.getRemark());
    insertReceiptItems(receipt.getId(), effective);
    return buildResult(receipt, next);
}
```

关键 SQL：

```sql
UPDATE po_order_item
   SET received_qty = received_qty + #{qty}, row_version = row_version + 1, updated_at = NOW()
 WHERE id = #{itemId} AND order_id = #{orderId} AND received_qty + #{qty} <= quantity;

UPDATE po_order
   SET status = #{next}, row_version = row_version + 1,
       completed_at = IF(#{next} = 'COMPLETED', NOW(), completed_at), updated_at = NOW()
 WHERE id = #{orderId} AND status = #{expectedStatus} AND row_version = #{rowVersion};
```

## 5. 状态推进

```
PENDING_RECEIVE    --首次收货，未收齐--> PARTIALLY_RECEIVED
PARTIALLY_RECEIVED --继续收货，未收齐--> PARTIALLY_RECEIVED
PENDING_RECEIVE    --首次收货即全收齐--> COMPLETED
PARTIALLY_RECEIVED --补齐--> COMPLETED
```

判定标准：**所有订单行** `received_qty = quantity`（不是"本次有效行都收满"）。用 `SELECT COUNT(*) FROM po_order_item WHERE order_id=? AND received_qty < quantity` 是否为 0 判定，避免在 Java 侧用可能过期的缓存列表计算。

`COMPLETED` 与 `PENDING_ORDER` 不提供收货入口；服务端收到请求返回 422，不依赖前端隐藏。

## 6. 权限与数据边界

| 角色 | 待收货列表 | 收货登记 | 说明 |
| --- | --- | --- | --- |
| 仓管 | 可见 | 允许 | 唯一可写角色 |
| 采购 | 可见 | 403 | 可看订单与收货记录，不登记 |
| 申请人/主管 | 关联订单只读 | 403 | 仅本人/本部门关联 |
| 财务 | 403 | 403 | **不得读取订单与收货记录**，不返回空列表 |

## 7. 异常清单

| 场景 | HTTP | 业务码 | 附带数据 |
| --- | --- | --- | --- |
| 非仓管调用 | 403 | `FORBIDDEN_ROLE` | — |
| 订单不存在 | 404 | `NOT_FOUND` | — |
| 订单已完成/未下单 | 422 | `INVALID_STATUS_TRANSITION` | 当前状态 |
| 全部行空或 0 | 422 | `EMPTY_RECEIPT_LINES` | — |
| 某行超收 | 409 | `OVER_RECEIPT` | `lineNo/pendingQty` |
| 并发导致累计变化 | 409 | `OVER_RECEIPT` 或 `STATE_CONFLICT` | 建议前端刷新 |
| 订单 `rowVersion` 过期 | 409 | `VERSION_CONFLICT` | 最新 `rowVersion` |
| 数量为负/小数 | 400 | `VALIDATION_FAILED` | 字段定位 |

## 8. 不可变与追溯

- `rc_receipt` 与 `rc_receipt_item` 只插入，不更新、不删除；无"撤销收货"接口。
- 每次登记生成独立记录号 `SH+yyyyMMdd+8位`，详情可核对登记人、时间、各行本次数量与备注。
- 行级累计量 `po_order_item.received_qty` 必须能由 `Σ rc_receipt_item.received_qty` 复算相等；建议提供只读核对 SQL 作为运维手段，不开放给业务页面。
- 并发下不需要分布式锁或重试：条件更新即冲突检测，冲突一律 409 交用户刷新后重试。

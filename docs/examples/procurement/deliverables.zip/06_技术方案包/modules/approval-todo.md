# 模块二：审批待办（approval-todo）

## 1. 职责边界

主管与财务共用一个待办模块，按当前角色决定列表内容与可执行动作。负责：待办查询、通过/驳回、轮次推进、审批留痕、代审判定。**不修改申请金额与行明细**，也不创建订单。待办不落表，是 `pr_application` 上状态的实时投影。

## 2. 页面与接口对照

| 页面 | 路由 | 动作 | 接口 |
| --- | --- | --- | --- |
| 审批待办 | `/approvals` | 列表、筛选、进入审批 | `GET /api/v1/approvals/todo` |
| 审批详情 | `/approvals/:applicationId` | 查看申请/用途/金额/轮次/历史，通过或驳回 | `GET /api/v1/purchase-requests/{id}`、`POST /api/v1/approvals/{applicationId}/decision` |

详情页复用申请详情的读模型，但隐藏编辑与提交动作，并把"通过/驳回"按钮放在底部固定区。驳回弹窗中理由为必填，取消不提交。通过/驳回都必须二次确认，确认文案要写明金额与下一步（"通过后将进入财务复核"）。

## 3. 待办查询规则

```
主管：WHERE status='PENDING_MANAGER'
        AND dept_id = :myDeptId
        AND applicant_id <> :myUserId
        AND 存在在职主管身份
财务：WHERE status='PENDING_FINANCE'
        AND applicant_id <> :myUserId
```

- 待办按 `submitted_at ASC`（先到先审）还是 `created_at DESC`？列表 UI 与基线"按创建时间倒序"一致，取 `created_at DESC`；不引入优先级与超时升级。
- `needFinance = total_amount_cents > 500000`，仅作列表标签（"需财务复核"），不参与路由计算，路由以决策时的实际金额为准。
- `isSelfApplication` 兜底标记：正常情况下本人申请已被 `applicant_id <> myUserId` 排除；若因代审授权查看他人单据，该字段为 false。
- 代审授权：`sys_user.can_delegate_approve=1` 的主管，可对**指定的对方本人**申请决策。实现用 `ApprovalScopeService` 判定：`applicant_id` 必须是授权对偶人（周禾↔许原），而不是"任意跨部门"。授权关系在 `sys_user` 上以布尔 + 固定映射维护，不引入授权表（案例范围）。

## 4. 决策流程与状态推进

```
输入：applicationId, action(APPROVE|REJECT), reason, roundNo, rowVersion, step
1. 加载申请；不存在 → 404
2. 校验当前角色与 step 匹配：
   step=MANAGER 需 MANAGER 且（同部门 或 命中代审）；step=FINANCE 需 FINANCE
3. 校验 applicant_id ≠ 当前用户，否则 403 SELF_APPROVAL_FORBIDDEN
4. 校验 status 与 step 一致（PENDING_MANAGER / PENDING_FINANCE），否则 422
5. 校验 roundNo == application.round_no，否则 409 VERSION_CONFLICT（旧轮次页面）
6. REJECT：reason 去空格后 1–200 字，否则 400 REASON_REQUIRED / VALIDATION_FAILED
7. 计算目标状态：
   APPROVE + total<=500000            → APPROVED
   APPROVE + total>500000 + step=MGR  → PENDING_FINANCE
   APPROVE + step=FINANCE             → APPROVED
   REJECT（任一 step）                 → REJECTED，写 last_reject_reason
8. UPDATE ... WHERE id=? AND status=<旧状态> AND row_version=?
9. INSERT pr_approval_record（唯一键 uk_app_round_step 防重复）
```

**金额路由唯一口径**：`total_amount_cents <= 500000` 单级（5,000.00 元整走单级）；`500001`（5,000.01）与 `860000`（8,600.00）两级。判断使用整数分，禁止用 `double` 或格式化后的字符串比较。

**通过后的下一步提示**：`needFinance=true` 时返回 `toStatus=PENDING_FINANCE, nextStep=FINANCE`，前端提示"已提交财务复核"；单级通过返回 `toStatus=APPROVED, nextStep=null`。

## 5. 并发与一致性

- 采用**单一条件更新**：`WHERE id=? AND status=? AND row_version=?`。影响 0 行即视为被他人抢先处理，返回 409 `STATE_CONFLICT`，前端刷新详情。不加重试循环、不加重试队列。
- `uk_app_round_step (application_id, round_no, step)` 保证同一轮同一环节只有一条终态；即使条件更新意外通过，第二条插入也会失败并回滚。
- 审批与申请状态在同一 `@Transactional` 内：更新主表 + 插入记录，任一失败全回滚。审批记录只增不改，不提供修改/删除接口。
- 主管通过与财务复核是两次独立事务（两个不同用户、不同时间），中间状态 `PENDING_FINANCE` 是可见的持久状态，不放在一个长事务里。

## 6. 权限边界

| 角色 | 待办可见 | 可决策 | 拒绝原因 |
| --- | --- | --- | --- |
| 主管 | 本部门 `PENDING_MANAGER` | 本部门且非本人；授权对偶人本人申请可代审 | 跨部门 → 403 `OUT_OF_DATA_SCOPE`；本人 → 403 `SELF_APPROVAL_FORBIDDEN` |
| 财务 | 跨部门 `PENDING_FINANCE` | 非本人 | 本人 → 403 `SELF_APPROVAL_FORBIDDEN` |
| 申请人/采购/仓管 | 无 | 无 | 403 `FORBIDDEN_ROLE` |

前端不显示"审批"菜单给无关角色，但这不是安全边界；每个决策请求都在服务端重新判定部门、角色、代审授权与自审。

## 7. 异常清单

| 场景 | HTTP | 业务码 |
| --- | --- | --- |
| 驳回未填理由 / 理由超 200 字 | 400 | `REASON_REQUIRED` / `VALIDATION_FAILED` |
| 审批人即申请人 | 403 | `SELF_APPROVAL_FORBIDDEN` |
| 跨部门主管审批 | 403 | `OUT_OF_DATA_SCOPE` |
| 非审批角色调用 | 403 | `FORBIDDEN_ROLE` |
| 单据已被他人处理 | 409 | `STATE_CONFLICT` |
| 页面停留旧轮次 / rowVersion 过期 | 409 | `VERSION_CONFLICT` |
| 对已批准/已驳回单决策 | 422 | `INVALID_STATUS_TRANSITION` |

## 8. 时间线展示口径

审批详情的时间线必须区分"审核通过""审核驳回""代审通过"，并展示理由（通过时可为空显示"—"）。历史轮次整体置灰并标注"第 N 轮（已结束）"，不可再操作。代审记录展示"许原（代 周禾 审批）"，数据来自 `is_delegate` 与 `delegate_of_user_id`。
